<?php

namespace AddonFlare\PaidRegistrations\AddonFlare\StripeCheckout\Payment;

use XF\Entity\PaymentProfile;
use XF\Entity\PurchaseRequest;
use XF\Mvc\Controller;
use XF\Purchasable\Purchase;

use XF\Payment\CallbackState;

class StripeCheckout extends XFCP_StripeCheckout
{
}