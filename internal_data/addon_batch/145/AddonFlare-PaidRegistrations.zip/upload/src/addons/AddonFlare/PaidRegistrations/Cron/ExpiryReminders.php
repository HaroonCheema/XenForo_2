<?php

namespace AddonFlare\PaidRegistrations\Cron;

class ExpiryReminders
{
    public static function process($entry)
    {
    }
}