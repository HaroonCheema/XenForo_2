<?php

namespace AddonFlare\PaidRegistrations\Notifier\UserUpgrade;

class ExpiryReminders extends \XF\Notifier\AbstractNotifier
{
}