<?php
namespace AddonFlare\PaidRegistrations\Service\UserUpgrade;

use XF\Entity\UserUpgrade;
use AddonFlare\PaidRegistrations\Entity\AccountType;

class Notifier extends \XF\Service\AbstractNotifier
{
}