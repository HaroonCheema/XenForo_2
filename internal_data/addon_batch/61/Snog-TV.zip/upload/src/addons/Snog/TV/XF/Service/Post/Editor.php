<?php

namespace Snog\TV\XF\Service\Post;

class Editor extends XFCP_Editor
{
	//
}