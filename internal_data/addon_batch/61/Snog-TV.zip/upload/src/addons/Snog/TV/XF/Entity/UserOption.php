<?php

namespace Snog\TV\XF\Entity;

/**
 * COLUMNS
 * @property string $snog_tv_tmdb_watch_region
 */
class UserOption extends XFCP_UserOption
{
	//
}