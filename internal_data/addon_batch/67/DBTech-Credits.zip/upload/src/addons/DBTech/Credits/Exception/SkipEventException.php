<?php

namespace DBTech\Credits\Exception;

/**
 * Class SkipEventException
 *
 * @package DBTech\Credits\Exception
 */
class SkipEventException extends \Exception
{
}