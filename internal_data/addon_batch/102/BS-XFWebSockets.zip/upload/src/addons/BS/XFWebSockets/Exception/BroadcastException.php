<?php

namespace BS\XFWebSockets\Exception;

class BroadcastException extends \RuntimeException
{
    //
}