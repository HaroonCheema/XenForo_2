<?php

namespace FS\Limitations;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;

        public function installstep1()
	{
            $sm = $this->schemaManager();
            
            $sm->alterTable('xf_user', function(Alter $table)
            {      
                $table->addColumn('daily_discussion_count', 'smallint', 5)->setDefault(0);
                $table->addColumn('conversation_message_count', 'int')->setDefault(0);
//                $table->addColumn('media_storage_size', 'bigint')->setDefault(0)->comment('size in bytes');
            });
	}

	public function uninstallStep1()
	{
                $sm = $this->schemaManager();
                $sm->alterTable('xf_user', function(Alter $table)
                {
                    $columns = [
                        'daily_discussion_count',
                        'conversation_message_count',
//                        'media_storage_size'
                    ];
                    
                    $table->dropColumns($columns);
                });
	}
        
}