<?php

namespace AVForums\TagEssentials\XF\Finder;

use SV\StandardLib\Finder\SqlJoinTrait;

class Tag extends XFCP_Tag
{
    use SqlJoinTrait;
}