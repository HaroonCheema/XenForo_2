<?php

namespace FS\BitCart\XF\Purchasable;

use XF\Payment\CallbackState;
use XF\Purchasable\Purchase;
use XF\Entity\PurchaseRequest;

class UserUpgrade extends XFCP_UserUpgrade
{
    
    
}