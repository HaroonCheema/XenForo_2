<?php

namespace xenbros\Threadthumbnail\Option;


use XF\Option\AbstractOption;

class Xenbrosverify extends AbstractOption
{
	
	public static function modify_box( \XF\Entity\Option $option)
	{	
		$outupt = ' ';
		return $outupt  ;
	}
}