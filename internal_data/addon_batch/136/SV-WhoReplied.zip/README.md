# Who Replied

Adds a list to show users who have replied to a thread.

Automatically adds permission for user-groups and forums where a user can see content
