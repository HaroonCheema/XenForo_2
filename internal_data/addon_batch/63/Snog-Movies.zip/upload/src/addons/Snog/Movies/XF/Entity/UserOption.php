<?php

namespace Snog\Movies\XF\Entity;

/**
 * COLUMNS
 * @property string $snog_movies_tmdb_watch_region
 */
class UserOption extends XFCP_UserOption
{
	//
}