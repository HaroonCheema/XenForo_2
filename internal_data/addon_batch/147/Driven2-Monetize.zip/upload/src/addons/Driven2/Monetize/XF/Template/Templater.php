<?php
namespace Driven2\Monetize\XF\Template;
Class Templater extends XFCP_Templater
{
    private $userwords;
    private $fatalwords;
    private $amazontag;
    private $country;
    private $applicable=true;
    public function fnBbCode($templater, &$escape, $bbCode, $context, $content, array $options = [], $type = 'html')
    {

        $option = \XF::options();
        $notApplicableForums=$option->d_monetizeExcludeForums;
        if($notApplicableForums)
        {
           $notApplicableForumsArray= explode(',', $notApplicableForums);
           if((in_array($content->Thread->node_id,$notApplicableForumsArray)))
            {
                $this->applicable=false;
            }
        }
        if($context=='post' && \XF::visitor()->hasPermission('d_monetize','d_monetize') && $this->applicable) {

            $this->userwords = $option->d_monetizeWordsString;
            $this->country = $this->GetCountry();
            if ($this->country == 'CA') {
                $this->amazontag = $option->d_monetizeAmazonTagStringCA;
            } else {
                $this->amazontag = $option->d_monetizeAmazonTagString;
            }
            $this->defaultsearch = $option->d_monetizeDefaultSearch;
            // Grab keywords from thread title
            $title = $this->removeStopWords($content->Thread->title);
            $keywords = $title . ' ' . $this->removeStopWords( $this->userwords );
            // If no fatal words in title
            if ( $this->fatalWords( $keywords ) != 1 )
            {
                    if ( $this->fatalWords( $content->message ) != 1 )
                    {
                        $bbCode= $this->insertMonetizeTags( $content->message, $title, $keywords );

                        return  parent::fnBbCode($templater, $escape, $bbCode, $context, $content,  $options ,$type);
                    }
            }
           return  parent::fnBbCode($templater, $escape, $bbCode, $context, $content,  $options ,$type);
        }
        else{
            return parent::fnBbCode($templater, $escape, $bbCode, $context, $content,  $options ,$type);
        }
    }

    private function insertMonetizeTags( $post, $title, $keywords )
    {
        $keywords = str_replace( ' ', '+', $keywords );

        /*	        $post = preg_replace( '/\[attach=full\](\d+)\[\/attach\]/im',
                              '[EURL=https://www.amazon.com/s?&tag=' . $this->amazontag .
                              '&i=automotive&k=' . $keywords .
                              '|' . $title . '][ATTACH=full]\1[/ATTACH][/EURL]#ad ',
                              $post );

                        $this->debuglog( $post );

                        $post = preg_replace( '/(\[url\S+)?\[img\](\S+)\[\/img\](\[\/url\])?/im',
                                              '[EURL=https://www.amazon.com/s?&tag=' . $this->amazontag .
                                              '&i=automotive&k=' . $keywords .
                                              '|' . $title . '][IMG]\2[/IMG][/EURL]#ad ',
                                              $post );

                        $this->debuglog( "Changed:" );

                        $this->debuglog( $post );
        */


        /***************************************************************************************************
         ** 03-13-2019 : Note from Ken - do not change this linking method.  I tried other "valid" methods **
         **		and found Amazon **fails** to record most clicks!                                 **
         ***************************************************************************************************/
        $post = preg_replace( '/\[attach type="full"\](\d+)\[\/attach\]/im',
            '[EURL=https://www.amazon.com/s/ref=as_li_ss_tl?url=search-alias=automotive&field-keywords=' .
            $keywords .
            '&linkCode=ll2&tag=' .
            $this->amazontag .
            '|' . $title . "][attach type=full]\\1[/attach][/EURL][SIZE=2]#ad[/SIZE]\r ",
            $post );


        $post = preg_replace( '/(\[url\S+)?\[img\](\S+)\[\/img\](\[\/url\])?/im',
            '[EURL=https://www.amazon.com/s/ref=as_li_ss_tl?url=search-alias=automotive&field-keywords=' .
            $keywords .
            '&linkCode=ll2&tag=' .
            $this->amazontag .
            '|' . $title . "][IMG]\\2[/IMG][/EURL][SIZE=2]#ad[/SIZE]\r ",
            $post );
        return $post;
    }
    private function fatalWords( $text )
    {
        if ( $this->fatalwords != '' )
        {
            return preg_match( '/(' . str_replace( ',', '|', $this->fatalwords ) . ')/i', $text );
        }
        return false;
    }
    private function GetCountry()
    {
        if ( getenv('GEOIP_COUNTRY_CODE') != FALSE )
        {
            return getenv('GEOIP_COUNTRY_CODE');
        }
        else if ( getenv('MM_COUNTRY_CODE') != FALSE )
        {
            return getenv('MM_COUNTRY_CODE');
        }
        else if ( function_exists('geoip_db_avail') && geoip_db_avail(GEOIP_COUNTRY_EDITION) )
        {
            return geoip_country_code_by_name( $_SERVER['REMOTE_ADDR'] );
        }
        return false;
    }
    private function removeStopWords( $text )
    {

        // Stop words
        static $stopWords = array( 'https', 'http', '[a-z][a-z]', 'a','able','about','above','abroad','according','accordingly','across','actually','adj','after','afterwards','again','against','ago','ahead','ain\'t','all','allow','allows','almost','alone','along','alongside','already','also','although','always','am','amid','amidst','among','amongst','an','and','another','any','anybody','anyhow','anyone','anything','anyway','anyways','anywhere','apart','appear','appreciate','appropriate','are','aren\'t','around','as','a\'s','aside','ask','asking','associated','at','available','away','awfully','b','back','backward','backwards','be','became','because','become','becomes','becoming','been','before','beforehand','begin','behind','being','believe','below','beside','besides','best','better','between','beyond','both','brief','but','by','c','came','can','cannot','cant','can\'t','caption','cause','causes','certain','certainly','changes','clearly','c\'mon','co','co.','com','come','comes','concerning','consequently','consider','considering','contain','containing','contains','corresponding','could','couldn\'t','course','c\'s','currently','d','dare','daren\'t','definitely','described','despite','did','didn\'t','different','directly','do','does','doesn\'t','doing','done','don\'t','down','downwards','during','e','each','edu','eg','eight','eighty','either','else','elsewhere','end','ending','enough','entirely','especially','et','etc','even','ever','evermore','every','everybody','everyone','everything','everywhere','ex','exactly','example','except','f','fairly','far','farther','few','fewer','fifth','first','five','followed','following','follows','for','forever','former','formerly','forth','forward','found','four','from','further','furthermore','g','get','gets','getting','given','gives','go','goes','going','gone','got','gotten','greetings','h','had','hadn\'t','half','happens','hardly','has','hasn\'t','have','haven\'t','having','he','he\'d','he\'ll','hello','help','hence','her','here','hereafter','hereby','herein','here\'s','hereupon','hers','herself','he\'s','hi','him','himself','his','hither','hopefully','how','howbeit','however','hundred','i','i\'d','ie','if','ignored','i\'ll','i\'m','immediate','in','inasmuch','inc','inc.','indeed','indicate','indicated','indicates','inner','inside','insofar','instead','into','inward','is','isn\'t','it','it\'d','it\'ll','its','it\'s','itself','i\'ve','j','just','k','keep','keeps','kept','know','known','knows','l','last','lately','later','latter','latterly','least','less','lest','let','let\'s','like','liked','likely','likewise','little','look','looking','looks','low','lower','ltd','m','made','mainly','make','makes','many','may','maybe','mayn\'t','me','mean','meantime','meanwhile','merely','might','mightn\'t','mine','minus','miss','more','moreover','most','mostly','mr','mrs','much','must','mustn\'t','my','myself','n','name','namely','nd','near','nearly','necessary','need','needn\'t','needs','neither','never','neverf','neverless','nevertheless','new','next','nine','ninety','no','nobody','non','none','nonetheless','noone','no-one','nor','normally','not','nothing','notwithstanding','novel','now','nowhere','o','obviously','of','off','often','oh','ok','okay','old','on','once','one','ones','one\'s','only','onto','opposite','or','other','others','otherwise','ought','oughtn\'t','our','ours','ourselves','out','outside','over','overall','own','p','particular','particularly','past','per','perhaps','placed','please','plus','possible','presumably','probably','provided','provides','q','que','quite','qv','r','rather','rd','re','really','reasonably','recent','recently','regarding','regardless','regards','relatively','respectively','right','round','s','said','sale','same','saw','say','saying','says','second','secondly','see','seeing','seem','seemed','seeming','seems','seen','self','selves','sensible','sent','serious','seriously','seven','several','shall','shan\'t','she','she\'d','she\'ll','she\'s','should','shouldn\'t','since','six','so','some','somebody','someday','somehow','someone','something','sometime','sometimes','somewhat','somewhere','soon','sorry','specified','specify','specifying','still','sub','such','sup','sure','t','take','taken','taking','tell','tends','th','than','thank','thanks','thanx','that','that\'ll','thats','that\'s','that\'ve','the','their','theirs','them','themselves','then','thence','there','thereafter','thereby','there\'d','therefore','therein','there\'ll','there\'re','theres','there\'s','thereupon','there\'ve','these','they','they\'d','they\'ll','they\'re','they\'ve','thing','things','think','third','thirty','this','thorough','thoroughly','those','though','thread','three','through','throughout','thru','thus','till','to','together','topic','too','took','toward','towards','tried','tries','truly','try','trying','t\'s','twice','two','u','un','under','underneath','undoing','unfortunately','unless','unlike','unlikely','until','unto','up','upon','upwards','us','use','used','useful','uses','using','usually','v','value','various','versus','very','via','viz','vs','w','want','wants','was','wasn\'t','way','we','we\'d','welcome','well','we\'ll','went','were','we\'re','weren\'t','we\'ve','what','whatever','what\'ll','what\'s','what\'ve','when','whence','whenever','where','whereafter','whereas','whereby','wherein','where\'s','whereupon','wherever','whether','which','whichever','while','whilst','whither','who','who\'d','whoever','whole','who\'ll','whom','whomever','who\'s','whose','why','will','willing','wish','with','within','without','wonder','won\'t','would','wouldn\'t','x','y','yes','yet','you','you\'d','you\'ll','your','you\'re','yours','yourself','yourselves','you\'ve','z','zero',
            /* Banned words */
            'a55','a55hole','aeolus','ahole','anal','analprobe','anilingus','anus','areola','areole','arian','aryan','ass','assbang','assbanged','assbangs','asses','assfuck','assfucker','assh0le','asshat','assho1e','ass hole','assholes','assmaster','assmunch','asswipe','asswipes','azazel','azz','b1tch','babe','babes','ballsack','bang','banger','barf','bastard','bastards','bawdy','beaner','beardedclam','beastiality','beatch','beater','beaver','beer','beeyotch','beotch','biatch','bigtits','big tits','bimbo','bitch','bitched','bitches','bitchy','blow job','blow','blowjob','blowjobs','bod','bodily','boink','bollock','bollocks','bollok','bone','boned','boner','boners','bong','boob','boobies','boobs','booby','booger','bookie','bootee','bootie','booty','booze','boozer','boozy','bosom','bosomy','bowel','bowels','bra','brassiere','breast','breasts','bugger','bukkake','bullshit','bull shit','bullshits','bullshitted','bullturds','bung','busty','butt','butt fuck','buttfuck','buttfucker','buttfucker','buttplug','c.0.c.k','c.o.c.k.','c.u.n.t','c0ck','c-0-c-k','caca','cahone','cameltoe','carpetmuncher','cawk','cervix','chinc','chincs','chink','chink','chode','chodes','cl1t','climax','clit','clitoris','clitorus','clits','clitty','cocain','cocaine','cock','c-o-c-k','cockblock','cockholster','cockknocker','cocks','cocksmoker','cocksucker','cock sucker','coital','commie','condom','coon','coons','corksucker','crabs','crack','cracker','crackwhore','crap','crappy','cum','cummin','cumming','cumshot','cumshots','cumslut','cumstain','cunilingus','cunnilingus','cunny','cunt','cunt','c-u-n-t','cuntface','cunthunter','cuntlick','cuntlicker','cunts','d0ng','d0uch3','d0uche','d1ck','d1ld0','d1ldo','dago','dagos','dammit','damn','damned','damnit','dawgie-style','dick','dickbag','dickdipper','dickface','dickflipper','dickhead','dickheads','dickish','dick-ish','dickripper','dicksipper','dickweed','dickwhipper','dickzipper','diddle','dike','dildo','dildos','diligaf','dillweed','dimwit','dingle','dipship','doggie-style','doggy-style','dong','doofus','doosh','dopey','douch3','douche','douchebag','douchebags','douchey','drunk','dumass','dumbass','dumbasses','dummy','dyke','dykes','ejaculate','enlargement','erect','erection','erotic','essohbee','extacy','extasy','f.u.c.k','fack','fag','fagg','fagged','faggit','faggot','fagot','fags','faig','faigt','fannybandit','fart','fartknocker','fat','felch','felcher','felching','fellate','fellatio','feltch','feltcher','fisted','fisting','fisty','floozy','foad','fondle','foobar','foreskin','freex','frigg','frigga','fubar','fuck','f-u-c-k','fuckass','fucked','fucked','fucker','fuckface','fuckin','fucking','fucknugget','fucknut','fuckoff','fucks','fucktard','fuck-tard','fuckup','fuckwad','fuckwit','fudgepacker','fuk','fvck','fxck','gae','gai','ganja','gay','gays','gey','gfy','ghay','ghey','gigolo','glans','goatse','godamn','godamnit','goddam','goddammit','goddamn','goldenshower','gonad','gonads','gook','gooks','gringo','gspot','g-spot','gtfo','guido','h0m0','h0mo','handjob','hard on','he11','hebe','heeb','hell','hemp','heroin','herp','herpes','herpy','hitler','hiv','hobag','hom0','homey','homo','homoey','honky','hooch','hookah','hooker','hoor','hootch','hooter','hooters','horny','hump','humped','humping','hussy','hymen','inbred','incest','injun','j3rk0ff','jackass','jackhole','jackoff','jap','japs','jerk','jerk0ff','jerked','jerkoff','jism','jiz','jizm','jizz','jizzed','junkie','junky','kike','kikes','kill','kinky','kkk','klan','knobend','kooch','kooches','kootch','kraut','kyke','labia','lech','leper','lesbians','lesbo','lesbos','lez','lezbian','lezbians','lezbo','lezbos','lezzie','lezzies','lezzy','lmao','lmfao','loin','loins','lube','lusty','mams','massa','masterbate','masterbating','masterbation','masturbate','masturbating','masturbation','maxi','menses','menstruate','menstruation','meth','m-fucking','mofo','molest','moolie','moron','motherfucka','motherfucker','motherfucking','mtherfucker','mthrfucker','mthrfucking','muff','muffdiver','murder','muthafuckaz','muthafucker','mutherfucker','mutherfucking','muthrfucking','nad','nads','naked','napalm','nappy','nazi','nazism','negro','nigga','niggah','niggas','niggaz','nigger','nigger','niggers','niggle','niglet','nimrod','ninny','nipple','nooky','nympho','opiate','opium','oral','orally','organ','orgasm','orgasmic','orgies','orgy','ovary','ovum','ovums','p.u.s.s.y.','paddy','paki','pantie','panties','panty','pastie','pasty','pcp','pecker','pedo','pedophile','pedophilia','pedophiliac','pee','peepee','penetrate','penetration','penial','penile','penis','perversion','peyote','phalli','phallic','phuck','pillowbiter','pimp','pinko','piss','pissed','pissoff','piss-off','pms','polack','pollock','poon','poontang','porn','porno','pornography','pot','potty','prick','prig','prostitute','prude','pube','pubic','pubis','punkass','punky','puss','pussies','pussy','pussypounder','puto','queaf','queef','queef','queer','queero','queers','quicky','quim','racy','rape','raped','raper','rapist','raunch','rectal','rectum','rectus','reefer','reetard','reich','retard','retarded','revue','rimjob','ritard','rtard','r-tard','rum','rump','rumprammer','ruski','s.h.i.t.','s.o.b.','s0b','sadism','sadist','scag','scantily','schizo','schlong','screw','screwed','scrog','scrot','scrote','scrotum','scrud','scum','seaman','seamen','seduce','semen','sex','sexual','sh1t','s-h-1-t','shamedame','shit','s-h-i-t','shite','shiteater','shitface','shithead','shithole','shithouse','shits','shitt','shitted','shitter','shitty','shiz','sissy','skag','skank','slave','sleaze','sleazy','slut','slutdumper','slutkiss','sluts','smegma','smut','smutty','snatch','sniper','snuff','s-o-b','sodom','souse','soused','sperm','spic','spick','spik','spiks','spooge','spunk','steamy','stfu','stiffy','stoned','strip','stroke','stupid','suck','sucked','sucking','sumofabiatch','t1t','tampon','tard','tawdry','teabagging','teat','terd','teste','testee','testes','testicle','testis','thrust','thug','tinkle','tit','titfuck','titi','tits','tittiefucker','titties','titty','tittyfuck','tittyfucker','toke','toots','tramp','transsexual','trashy','tubgirl','turd','tush','twat','twats','ugly','undies','unwed','urinal','urine','uterus','uzi','vag','vagina','valium','viagra','virgin','vixen','vodka','vomit','voyeur','vulgar','vulva','wad','wang','wank','wanker','wazoo','wedgie','weed','weenie','weewee','weiner','weirdo','wench','wetback','wh0re','wh0reface','whitey','whiz','whoralicious','whore','whorealicious','whored','whoreface','whorehopper','whorehouse','whores','whoring','wigger','womb','woody','wop','wtf','x-rated','xxx','yeasty','yobbo','zoophile', ' [0-9] ' );

        $text = preg_replace( '/[^a-z\d \.]+/i', ' ', $text );

        $text = str_replace( array( '%20' ), ' ', $text );
        $text = preg_replace( '/\b(' . implode( '|', $stopWords ) .' )\b/i',' ', $text );
        $text = preg_replace( '/\s+/', ' ', $text );
        return ltrim( rtrim( $text, " \t\n\r\0\x0B\." ), " \t\n\r\0\x0B\." );
    }
}