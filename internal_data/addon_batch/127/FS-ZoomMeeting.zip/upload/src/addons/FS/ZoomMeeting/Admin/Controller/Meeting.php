<?php

namespace FS\ZoomMeeting\Admin\Controller;

use XF\Mvc\ParameterBag;
use XF\Admin\Controller\AbstractController;
use XF\Mvc\RouteMatch;

class Meeting extends AbstractController {

    public function actionIndex(ParameterBag $params) {

        if ($this->filter('search', 'uint')) {
            $finder = $this->getSearchFinder();
        } else {
            $finder = $this->finder('FS\ZoomMeeting:Meeting');
        }

        $page = $this->filterPage($params->page);
        $perPage = 15;
        $finder->limitByPage($page, $perPage);

        $viewpParams = [
            'page' => $page,
            'total' => $finder->total(),
            'perPage' => $perPage,
            'meetings' => $finder->order('created_date', 'DESC')->fetch(),
            'conditions' => $this->filterSearchConditions(),
        ];

        return $this->view('FS\ZoomMeeting:Meeting', 'zoom_meetings', $viewpParams);
    }

    public function meetingAddEdit($meeting) {


        $categories = $this->Finder('FS\ZoomMeeting:Category')->order('category_id', 'DESC')->fetch();

        $nodeTree = $this->getNodeTree();
        $viewParams = [
            'meeting' => $meeting,
            'categories' => $categories,
            'nodeTree' => $nodeTree,
        ];

        return $this->view('FS\ZoomMeeting:Meeting', 'edit_zoom_meeting', $viewParams);
    }

    public function actionEdit(ParameterBag $params) {

        $meeting = $this->assertMeetingExists($params->meeting_id);

        return $this->meetingAddEdit($meeting);
    }

    public function actionAdd() {

        $meeting = $this->em()->create('FS\ZoomMeeting:Meeting');

        return $this->meetingAddEdit($meeting);
    }

    protected function meetingSaveProcess(\FS\ZoomMeeting\Entity\Meeting $meeting) {
        $form = $this->formAction();

        $input = $this->filter([
            'topic' => 'str',
            'category_id' => 'int',
            'start_date' => 'str',
            'start_time' => 'str',
            'duration' => 'int',
            'thread_title' => 'str',
            'forum_id' => 'int',
            
        ]);
        
        
       
        $startDate=$input['start_date'];
        $startTime=$input['start_time'];
        
        
        
        $input['description'] = $this->plugin('XF:Editor')->fromInput('description');
        
        $timezone = "UTC";
        
        $tz = new \DateTimeZone($timezone);

        $dateTime = new \DateTime("@" . strtotime($startDate), $tz);

        list($hours, $minutes) = explode(':', $startTime);


        $dateTime->setTime($hours, $minutes);
        $stimestamp = $dateTime->getTimestamp();
        
        $input['start_time']=$stimestamp;
        
        
        $meetingService = $this->service('FS\ZoomMeeting:Meeting');
        
        $zoomStartTime=$meetingService->zoomMeetingTime($startDate,$startTime);
       
        
        $topic=$input['topic'];
        
        $duration=$input['duration'];
        
        
      
        list($z_meetingId,$z_start_time,$z_start_url,$z_join_url)=$meetingService->createZoomMeeting($topic, $zoomStartTime, $duration, $timezone, \xf::options()->zoom_access_token);
        
        $input['z_meeting_id']=$z_meetingId;
        $input['z_start_time']=$z_start_time;
        $input['z_start_url']=$z_start_url;
        $input['z_join_url']=$z_join_url;
        
        if($input['forum_id']){
            
            $threadTitle=$input['thread_title'] ?  $input['thread_title'] : $topic;
            
            $thread=$meetingService->createDisuccion($input['forum_id'] ,$threadTitle,$input['description']);
            
            if($thread){
                
                $input['thread_id']=$thread->thread_id;
            }
            
        }
        
        $this->beforeSave($input);
        
	$form->basicEntitySave($meeting, $input);
        
        return $form;
        
    }
    
    public function beforeSave(&$input){
        
        unset($input['thread_title']);
        unset($input['start_date']);
    }
    
    

    public function actionSave(ParameterBag $params) {
        
        
        if(!\xf::options()->zoom_access_token){
            
            
        }

        $this->assertPostOnly();

        if ($params->item_id) {
            $meeting = $this->assertMeetingExists($params->meeting_id);
        } else {
            $meeting = $this->em()->create('FS\ZoomMeeting:Meeting');
        }


        $this->meetingSaveProcess($meeting)->run();
        
         return $this->redirect($this->buildLink('meetings'));
    }

    protected function assertMeetingExists($id, $with = null, $phraseKey = null) {
        return $this->assertRecordExists('FS\ZoomMeeting:Meeting', $id, $with, $phraseKey);
    }

    protected function getNodeTree() {
        $nodeRepo = \XF::repository('XF:Node');
        $nodeTree = $nodeRepo->createNodeTree($nodeRepo->getFullNodeList());

        // only list nodes that are forums or contain forums
        $nodeTree = $nodeTree->filter(null, function ($id, $node, $depth, $children, $tree) {
            return ($children || $node->node_type_id == 'Forum');
        });

        return $nodeTree;
    }

    protected function getSearchFinder() {
        $conditions = $this->filterSearchConditions();

        $finder = $this->finder('XC\Escrow:Escrow');

        if ($conditions['creater_username'] != '') {

            $User = $this->finder('XF:User')->where('username', $conditions['mention_username'])->fetchOne();
            if ($User) {
                $finder->where('user_id', $User['user_id']);
            }
        }
        if ($conditions['mention_username'] != '') {

            $User = $this->finder('XF:User')->where('username', $conditions['mention_username'])->fetchOne();
            if ($User) {
                $finder->where('to_user', $User['user_id']);
            }
        }

        if ($conditions['status'] != 'all') {
            if (intval($conditions['status']) >= 0 && intval($conditions['status']) <= 7) {
                $finder->where('status', intval($conditions['status']));
            }
        }


        return $finder;
    }

    public function filterPage($page = 0, $inputName = 'page') {
        return max(1, intval($page) ?: $this->filter($inputName, 'uint'));
    }

    public function actionRefineSearch(ParameterBag $params) {

        $viewParams = [
            'conditions' => $this->filterSearchConditions(),
        ];
        return $this->view('XC\Escrow:Escrow', 'xc_escrow_search_filter', $viewParams);
    }

    protected function filterSearchConditions() {
        $filters = $this->filter([
            'status' => 'str',
            'mention_username' => 'str',
            'type' => 'str',
            'creater_username' => 'str',
        ]);
        //   if ($filters['type']=='my'){
        //         $filters['isSelected'] = 'my';
        //     }
        //     else if ($filters['type']=='mentioned'){
        //         $filters['isSelected'] = 'mentioned';
        //     }
        return $filters;
    }
}
