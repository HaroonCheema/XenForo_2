<?php

namespace Siropu\AdsManager\Finder;

use XF\Mvc\Entity\Finder;

class ClickStats extends AbstractStats {}
