<?php

namespace Siropu\AdsManager\Finder;

use XF\Mvc\Entity\Finder;

class DailyStats extends AbstractStats {}
