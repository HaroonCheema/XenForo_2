<?php

namespace AL\Core\XF\Entity;

use AL\Core\Compat;
use XF\Mvc\Entity\Structure;

/**
 * Class SessionActivity
 * @package AL\Core\XF\Entity
 *
 * @property string $controller_name_
 */
class  SessionActivity extends XFCP_SessionActivity
{

}