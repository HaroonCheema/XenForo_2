<?php
namespace AddonsLab\Core\Service;

interface AccountDeleterInterface
{
    public function deleteAccountById($accountId);
}