<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class UsernameRow extends AbstractRow
{
    protected $type = self::TYPE_USERNAME;
}