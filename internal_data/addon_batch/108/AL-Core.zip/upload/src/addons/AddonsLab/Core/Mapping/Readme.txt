Mappings are mirrors of DB in OOP and are used for structural reasons only. 
Public keys represent the columns in the database. 
No methods are allowed in the mappings except for helpers to handle from/to array conversion.