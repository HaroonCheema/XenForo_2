<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class SpinboxRow extends AbstractRow
{
    protected $type = self::TYPE_SPINBOX;
}