<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class RadioRow extends AbstractRow
{
    protected $type = self::TYPE_RADIO;
}