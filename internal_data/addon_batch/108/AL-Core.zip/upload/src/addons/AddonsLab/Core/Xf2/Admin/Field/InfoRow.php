<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class InfoRow extends AbstractRow
{
    protected $type = self::TYPE_INFO;
}