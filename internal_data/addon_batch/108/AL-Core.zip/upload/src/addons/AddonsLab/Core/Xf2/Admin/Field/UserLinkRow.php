<?php
namespace AddonsLab\Core\Xf2\Admin\Field;
class UserLinkRow extends InfoRow
{
    protected $type = self::TYPE_CUSTOM;
    protected $template_name = 'user_link';
}