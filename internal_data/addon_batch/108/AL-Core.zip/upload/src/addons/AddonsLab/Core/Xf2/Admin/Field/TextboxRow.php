<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class TextboxRow extends AbstractRow
{
    protected $type = self::TYPE_TEXTBOX;
}