<?php
namespace AddonsLab\Core\Service;

interface ServiceInterface
{
    public function setApp();
    public function getApp();
}