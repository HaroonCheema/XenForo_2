<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class OnOffTextboxRow extends AbstractRow
{
    protected $type = self::TYPE_ONOFFTEXTBOX;
}