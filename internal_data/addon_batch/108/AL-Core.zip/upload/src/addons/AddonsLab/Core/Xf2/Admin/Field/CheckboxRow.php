<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class CheckboxRow extends AbstractRow
{
    protected $type = self::TYPE_CHECKBOX;
}