<?php

namespace AddonsLab\Core\Xf2\Admin;

use XF\PrintableException;

class AdminAccessException extends \RuntimeException
{

}