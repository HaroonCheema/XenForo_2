<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class DateboxRow extends AbstractRow
{
    protected $type = self::TYPE_DATEBOX;
}