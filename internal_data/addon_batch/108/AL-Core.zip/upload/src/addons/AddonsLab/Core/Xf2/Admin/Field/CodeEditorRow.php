<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class CodeEditorRow extends AbstractRow
{
    protected $type = self::TYPE_CODEEDITOR;
}