<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class TextAreaRow extends AbstractRow
{
    protected $type = self::TYPE_TEXTAREA;
}