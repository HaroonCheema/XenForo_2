<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class OnOffRow extends AbstractRow
{
    protected $type = self::TYPE_ONOFF;
}