<?php

namespace AddonsLab\Core\Xf2\Admin\Field;

class SelectRow extends AbstractRow
{
    protected $type = self::TYPE_SELECT;
}