<?php
namespace Aws\DAX\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **Amazon DynamoDB Accelerator (DAX)** service.
 */
class DAXException extends AwsException {}
