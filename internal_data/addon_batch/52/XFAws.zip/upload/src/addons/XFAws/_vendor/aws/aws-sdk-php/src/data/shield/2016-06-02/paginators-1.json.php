<?php
// This file was auto-generated from sdk-root/src/data/shield/2016-06-02/paginators-1.json
return [ 'pagination' => [],];
