<?php

namespace SV\MultiPrefix\DBTech\eCommerce\Repository;

use SV\MultiPrefix\Repository\MultiPrefixRepoTrait;

class CategoryPrefix extends XFCP_CategoryPrefix
{
    use MultiPrefixRepoTrait;
}