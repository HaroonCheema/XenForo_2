<?php

namespace SV\MultiPrefix\XFRM\Repository;

use SV\MultiPrefix\Repository\MultiPrefixRepoTrait;

class CategoryPrefix extends XFCP_CategoryPrefix
{
    use MultiPrefixRepoTrait;
}