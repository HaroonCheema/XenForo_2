<?php

namespace OzzModz\Badges\XF\Entity;


/**
 * @property bool $ozzmodz_badges_email_on_award
 */
class UserOption extends XFCP_UserOption
{
}