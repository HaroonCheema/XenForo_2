/** @param {jQuery} $ jQuery Object */
(function($, window, document, _undefined)
{
    "use strict";

    $("#phone-search").on("submit", function(event) {

        event.preventDefault();

        let form = $("#phone-search"),
            phone = form.find("input[name='phone']").val(),
            url = form.attr('action') + "?phone=" + phone

        $.ajax({
            method: 'GET',
            url: XF.canonicalizeUrl(url),
            success: function (response) {
                const urls = response.urls;
                let html = '';
                if (urls.length > 0) {
                    // Loop through the URLs array and create an HTML string for each URL
                    let urlsHtml = '';
                    for (let i = 0; i < urls.length; i++) {
                        urlsHtml += `<li><a href="${urls[i].url}" target="_blank">${urls[i].city} - ${urls[i].title}</a></li>`;
                    }
                    html = "<b>These are the matches found:</b><ul>" + urlsHtml + "</ul>";
                } else {
                    html = "<b>No matches found.</b>";
                }
                // Add the HTML string to the "remote-data" div
                $("#remote-data").html(html);
            },
            error: function(jqXHR, textStatus, ex) {
                alert(textStatus + "," + ex + "," + jqXHR.responseText);
            }
        });


    });

}) (jQuery, window, document);