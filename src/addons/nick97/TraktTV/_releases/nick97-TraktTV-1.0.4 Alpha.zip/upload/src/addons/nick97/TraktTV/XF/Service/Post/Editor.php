<?php

namespace nick97\TraktTV\XF\Service\Post;

class Editor extends XFCP_Editor
{
	//
}
