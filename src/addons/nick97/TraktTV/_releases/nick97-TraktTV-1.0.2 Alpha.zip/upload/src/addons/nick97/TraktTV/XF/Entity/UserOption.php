<?php

namespace nick97\TraktTV\XF\Entity;

/**
 * COLUMNS
 * @property string $nick97_tv_trakt_watch_region
 */
class UserOption extends XFCP_UserOption
{
	//
}
