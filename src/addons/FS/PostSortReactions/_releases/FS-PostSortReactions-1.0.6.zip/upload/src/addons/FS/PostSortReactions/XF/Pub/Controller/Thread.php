<?php

namespace FS\PostSortReactions\XF\Pub\Controller;

use XF\Mvc\ParameterBag;
use XF\Mvc\Entity\ArrayCollection;
use FS\PostPrefix\Helper;
use XF\ControllerPlugin\ThreadPlugin;
use XF\Repository\UserAlertRepository;
use XF\Repository\ThreadTypeRepository;

class Thread extends XFCP_Thread
{

    public function actionIndex(ParameterBag $params)
    {
        $parent = parent::actionIndex($params);

        $prefixId = $this->filter('prefix_id', 'str');
        $order = $this->filter('order', 'str');

        if ($parent instanceof \XF\Mvc\Reply\View) {
            $forum = $parent->getParam('forum');
            $prefixes = $forum->getUsablePrefixes();
            $prefixes = Helper::excludePrefixes($prefixes);

            // ********* Added by Wasif for Prefix dropdown option ********************
            //Grouped dropDown Menu New ****
            $db = \XF::db();
            $drpDownPrefixes = $db->fetchAll('
                SELECT
                distinct tp.prefix_group_id,fs.prefix_id 
                FROM fs_post_prefixes fs
                LEFT JOIN xf_post p on fs.post_id = p.post_id
                LEFT JOIN xf_thread t on p.thread_id = t.thread_id
                LEFT JOIN xf_thread_prefix tp on fs.prefix_id = tp.prefix_id
                where t.thread_id = ?
                order by case when tp.prefix_group_id = 0 then 99999 else tp.prefix_group_id end,fs.prefix_id
                ', ['thread_id' => $params->thread_id]);

            $drpMenu = [];

            foreach ($drpDownPrefixes as $item) {
                $drpMenu[$item["prefix_group_id"]][] = $item["prefix_id"];
            }

            $videosClipsIds = \XF::options()->pp_videos_and_clips_ids;
            $videosClipsIds = array_map('intval', array_filter(explode(",", $videosClipsIds)));

            //When at least 2 prefix ids provided in options then "Videos and Clips" menu will display
            if (count($videosClipsIds) > 1) {
                //Add Video and Clips prefix at specific index
                foreach ($drpMenu as $outerIndex => $innerArray) {
                    if (($innerIndex = array_search(max($videosClipsIds), $innerArray)) !== false) {
                        $foundIndex = [$outerIndex, $innerIndex];
                        array_splice($drpMenu[$outerIndex], $innerIndex + 1, 0, 'V');
                        break;
                    }
                }
            }

            $parent->setParam('preId', $prefixId);
            $parent->setParam('order', $order);
            $parent->setParam('prefixes', $prefixes);
            $parent->setParam('drpMenu', $drpMenu);                     //Grouped dropDown Menu New
        }

        if ($prefixId || $order) {

            $thread = $this->assertViewableThread($params->thread_id, $this->getThreadViewExtraWith());

            if ($order == 'post_date' and $prefixId)
                return $this->redirect($this->buildLink('threads', $thread, ['prefix_id' => $prefixId]));
            else if ($order == 'post_date' and !$prefixId)
                return $parent;


            $filters = $this->getPostListFilterInput($thread);
            $page = $this->filterPage($params->page);
            $perPage = $this->options()->messagesPerPage;

            $postRepo = $this->getPostRepo();

            $postList = $postRepo->findPostsForThreadView($thread);

            if ($prefixId) {
                $postIds = $this->finder('FS\PostPrefix:PostPrefixes')
                    ->with('Post')
                    ->where('prefix_id', explode(',', $prefixId))
                    ->where('Post.thread_id', $params->thread_id)
                    ->fetch()->pluckNamed('post_id');

                $postList = $postList->where('post_id', $postIds);
            }

            $this->applyPostListFilters($thread, $postList, $filters);

            $thread->TypeHandler->adjustThreadPostListFinder($thread, $postList, $page, $this->request);

            $visitor = \XF::visitor();

            if ($order and $visitor->user_id) {

                if ($order == 'reaction_all') {
                    $postList->order([
                        ['reaction_score', 'DESC'],
                        ['post_date', 'ASC']
                    ]);
                } else {
                    $timeCutoff = 0;

                    switch ($order) {
                        case 'reaction_1y':
                            $timeCutoff = \XF::$time - 31536000;
                            break;

                        case 'reaction_1m':
                            $timeCutoff = \XF::$time - 2592000;
                            break;

                        case 'reaction_7d':
                            $timeCutoff = \XF::$time - 604800;
                            break;

                        case 'reaction_today':
                            $timeCutoff = strtotime('today');
                            break;

                        default:
                            $timeCutoff = 0;
                    }

                    $reactionExpr = $postList->expression("
    (
        SELECT COALESCE(SUM(r.reaction_score), 0)
        FROM xf_reaction_content rc
        INNER JOIN xf_reaction r
            ON r.reaction_id = rc.reaction_id
        WHERE rc.content_type = 'post'
          AND rc.content_id = xf_post.post_id
          AND rc.reaction_date >= {$timeCutoff}
    )
");

                    $postList->order([
                        [$reactionExpr, 'DESC'],
                        ['reaction_score', 'DESC'],
                        ['post_date', 'ASC']
                    ]);
                }
            }

            $postList->limitByPage($page, $perPage);
            $posts = $postList->fetch();

            $totalPosts = $filters ? $postList->total() : ($thread->reply_count + 1);

            $this->assertValidPage($page, $perPage, $totalPosts, 'threads', $thread);

            if (!$filters && !$posts->count()) {
                return $parent;
            }

            $isFirstPostPinned = $thread->TypeHandler->isFirstPostPinned($thread);
            $highlightPostIds = $thread->TypeHandler->getHighlightedPostIds($thread, $filters);

            $extraFetchIds = [];

            if ($isFirstPostPinned && !isset($posts[$thread->first_post_id])) {
                $extraFetchIds[$thread->first_post_id] = $thread->first_post_id;
            }
            foreach ($highlightPostIds as $highlightPostId) {
                if (!isset($posts[$highlightPostId])) {
                    $extraFetchIds[$highlightPostId] = $highlightPostId;
                }
            }

            if ($extraFetchIds) {
                $extraFinder = $postRepo->findSpecificPostsForThreadView($thread, $extraFetchIds);

                $this->applyPostListFilters($thread, $extraFinder, $filters, $extraFetchIds);
                $thread->TypeHandler->adjustThreadPostListFinder(
                    $thread,
                    $extraFinder,
                    $page,
                    $this->request,
                    $extraFetchIds
                );

                $fetchPinnedPosts = $extraFinder->fetch();
                $posts = $posts->merge($fetchPinnedPosts);
            }

            $threadViewData = $thread->TypeHandler->setupThreadViewData($thread, $posts, $extraFetchIds);

            //Added by Wasif*************
            // $postPrefixes = $this->finder('FS\PostPrefix:PostPrefixes')->with('Post')->where('Post.thread_id', $params->thread_id)->fetch()->pluckNamed('prefix_id');
            // $postPrefixesText = [];

            // foreach ($postPrefixes as $key => $value) {
            //     $postPrefixesText[$prefixTitle = \XF::app()->templater()->fn('prefix_title', ['thread', $value])] = $value;
            // }
            //****************************

            $pageNavFilters = $this->getPostListFilterInput($thread);

            $pageNavFilters['order'] = $order;

            $parent->setParam('posts', $threadViewData->getMainPosts());
            $parent->setParam('pageNavFilters', $pageNavFilters);
            // $parent->setParam('posts', $posts);
        }

        return $parent;
    }

}
