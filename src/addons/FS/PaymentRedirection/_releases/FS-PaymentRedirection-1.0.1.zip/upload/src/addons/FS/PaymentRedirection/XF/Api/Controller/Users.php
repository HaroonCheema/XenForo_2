<?php

namespace FS\PaymentRedirection\XF\Api\Controller;

use XF\Mvc\Entity\Entity;
use XF\Mvc\ParameterBag;

class Users extends XFCP_Users
{
    public function actionPostUpgradeUser()
    {

        $user = false;
        $upgrade = false;

        $userId = $this->filter('user_id', 'int');
        $endDate = $this->filter('endDate', 'int');
        $userUpgradeId = $this->filter('user_upgrade_id', 'int');
        $upgradeTitle = $this->filter('title', 'str');

        $username = ltrim($this->filter('username', 'str', ['no-trim']));


        if ($username !== '' && utf8_strlen($username) >= 2) {
            $user = $this->em()->findOne('XF:User', ['username' => $username]);
        }

        if ($upgradeTitle !== '' && utf8_strlen($upgradeTitle) >= 2) {
            $upgrade = $this->em()->findOne('XF:UserUpgrade', ['title' => $upgradeTitle]);
        }

        if ($user && $upgrade) {

            /** @var \XF\Service\User\Upgrade $upgradeService */
            $upgradeService = $this->service('XF:User\Upgrade', $upgrade, $user);
            $upgradeService->setEndDate($endDate);
            $upgradeService->ignoreUnpurchasable(true);
            $upgradeService->upgrade();
        }

        return $this->apiSuccess();
    }
}
