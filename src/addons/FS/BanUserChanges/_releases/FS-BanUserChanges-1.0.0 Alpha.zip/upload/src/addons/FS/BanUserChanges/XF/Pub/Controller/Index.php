<?php

namespace FS\BanUserChanges\XF\Pub\Controller;

class Index extends XFCP_Index
{
    public function assertNotBanned()
    {
        // if (\XF::visitor()->is_banned) {
        //     throw $this->exception(
        //         $this->plugin('XF:Error')->actionBanned()
        //     );
        // }
    }
}
