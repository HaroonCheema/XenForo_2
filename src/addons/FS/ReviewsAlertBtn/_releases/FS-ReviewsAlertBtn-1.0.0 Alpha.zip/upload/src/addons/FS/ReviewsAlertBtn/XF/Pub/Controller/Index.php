<?php

namespace FS\BanUserChanges\XF\Pub\Controller;

class Index extends XFCP_Index
{
    public function assertNotBanned() {}
}
