<?php

namespace FS\ThreadScoringSystem\XF\Entity;

use XF\Mvc\Entity\Structure;

class Thread extends XFCP_Thread
{
    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        $structure->columns['points_collected'] =  ['type' => self::BOOL, 'default' => false];

        return $structure;
    }

    // protected function _postSave()
    // {
    //     if ($this->isUpdate() && $this->isChanged('')) {
    //     }

    //     return parent::_postSave();
    // }
}
