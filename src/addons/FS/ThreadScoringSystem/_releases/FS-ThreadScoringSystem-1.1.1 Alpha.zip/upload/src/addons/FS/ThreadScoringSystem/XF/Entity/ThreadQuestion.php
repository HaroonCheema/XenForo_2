<?php

namespace FS\ThreadScoringSystem\XF\Entity;

class ThreadQuestion extends XFCP_ThreadQuestion
{
 
    protected function _postDelete()
    {
        $parent = parent::_postDelete();

        $threadQuestion = $this;

        if ($threadQuestion->solution_user_id) {

            $deleteSolution = \XF::finder('FS\ThreadScoringSystem:ScoringSystem')->where('points_type', 'solution')->where('thread_id', $threadQuestion->thread_id)->fetch();

            if (count($deleteSolution)) {
                foreach ($deleteSolution as $value) {
                    $value->delete();
                }
            }
        }

        return $parent;
    }
}
