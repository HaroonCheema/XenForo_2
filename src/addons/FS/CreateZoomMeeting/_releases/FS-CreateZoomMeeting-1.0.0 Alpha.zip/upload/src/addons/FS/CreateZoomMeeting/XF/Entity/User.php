<?php

namespace FS\CreateZoomMeeting\XF\Entity;

use XF\Mvc\Entity\Structure;

use function is_array;

class User extends XFCP_User
{
	// public function canViewMeetings(&$error = null)
	// {
	// 	return $this->hasPermission('zoom_meeting', 'zoom_meeting_view');
	// }

        
}