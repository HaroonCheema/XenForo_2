<?php

namespace SV\MultiPrefix\XenConcept\ProjectManager\Repository;

use SV\MultiPrefix\Repository\MultiPrefixRepoTrait;

class CategoryPrefix extends XFCP_CategoryPrefix
{
    use MultiPrefixRepoTrait;
}