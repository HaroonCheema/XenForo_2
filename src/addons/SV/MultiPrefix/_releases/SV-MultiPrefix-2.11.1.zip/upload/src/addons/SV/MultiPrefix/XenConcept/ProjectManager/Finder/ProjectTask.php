<?php

namespace SV\MultiPrefix\XenConcept\ProjectManager\Finder;

class ProjectTask extends XFCP_ProjectTask
{

}