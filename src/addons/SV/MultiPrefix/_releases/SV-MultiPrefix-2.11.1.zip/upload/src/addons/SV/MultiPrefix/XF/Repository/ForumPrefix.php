<?php

namespace SV\MultiPrefix\XF\Repository;

use SV\MultiPrefix\Repository\MultiPrefixRepoTrait;

class ForumPrefix extends XFCP_ForumPrefix
{
    use MultiPrefixRepoTrait;
}